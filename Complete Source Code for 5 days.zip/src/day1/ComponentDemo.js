import { use, useState } from 'react'

const ComponentDemo = () => {

        //useState-->hook
    const[count,setCount]=useState(0);
    const[emp,setEmp]=useState({id:101,name:'John',sal:45000});
  return (
    <div>
        <h1>Count Value:{count}</h1>
        <button onClick={()=>setCount(count+1)}>Increment</button>
        <button onClick={()=>setCount(count-1)}>Drecrement</button>

        <h1>Employee Details</h1>
        <h2>Id:{emp.id}</h2>
        <h2>Name:{emp.name}</h2>
        <h2>Salary:{emp.sal}</h2>
        <button onClick={()=>setEmp({...emp,sal:emp.sal+5000})}>Increment Salary</button>
    </div>
  )
}

export default ComponentDemo




//rcc->react class component
//rfc->react functional component
//rafc->react arrow function component
//rfcce->react functional component with export
//rfce->react functional component with export default
//rconst->react constructor
//cc->react class component with constructor
