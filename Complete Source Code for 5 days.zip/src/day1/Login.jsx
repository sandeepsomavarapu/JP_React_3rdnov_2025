
function Demo()
{
    return <h2>Am from Demo Component</h2>
}
function Login(props){
        
    return <h2>Am from Login Component  {props.location}</h2>
}
export default Login;
export {Demo};