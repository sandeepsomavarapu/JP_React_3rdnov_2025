
import React from 'react';

class ClassDemo extends React.Component {
    name= 1;//variable
// define the state variable inside the constructor
    constructor(){
        super();
        //state variable
        this.state={
            count:0,
            orgname:'LTI'
        }
    }
    increment=()=>{
        this.setState({count:this.state.count+1})
    }
    render(){
        return(
        <div>
            <h1>Class Component {this.state.count} {this.state.orgname}</h1>
            <button onClick={this.increment}>Increment</button>  
          <button onClick={()=>{this.setState({count:this.state.count+1})}}>Increment</button> 

      </div>
        )
    }

}
export default ClassDemo;