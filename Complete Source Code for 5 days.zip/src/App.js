import { createContext, useContext, useState } from "react";
import Display from "./Day5/Salt/Display";
import Input from "./Day5/Salt/Input";
import { Context } from "./Day5/Salt/Context/Context";
import Parent1 from "./Day5/Salt/Context/Parent1";
import Parent2 from "./Day5/Salt/Context/Parent2";
import Parent3 from "./Day5/Salt/Context/Parent3";
import P1Child1 from "./Day5/Salt/Context/P1Child1";
import Parent from "./Day5/Salt/Parent";
import Navbar from "./Day3/Navbar";
import Demo from "./Day5/Salt/Memo/Demo";
import SaltFormDemo from "./Day5/Salt/SaltFormDemo";



const App = () => {
  return (
    <div>
      {/* <Navbar></Navbar> */}
     
      {/* <SaltFormDemo></SaltFormDemo> */}

    </div>
  )
}

export default App





// const App = () => {
//   const username="sandeep"
//   return (
//     <div>
//       {/* <Demo></Demo> */}
//       {/* <Navbar></Navbar> */}
//       <Parent username={username}></Parent>
//     </div>
//   )
// }

// export default App

// const App = () => {
//     const orgName="JPMC"
//   return (
//     <div>
//       <Parent orgName={orgName}></Parent>
//     </div>
//   )
// }

// export default App

//  const App = () => {
//   const [text, setText] = useState("");
//   return (
//     <div>
//       <Input setText={setText} />
//       <Display text={text} />
//     </div>
//   );
// }
// export default App;


// const App = () => {
//   const commonData = { id: 123, name: "sandeep" }
//   return (
//     <div>
//       <Context.Provider value={commonData}>
//         <Parent1></Parent1>
//         <Parent2></Parent2>
//         <Parent3></Parent3>
//       </Context.Provider>

//     </div>
//   )
// }

// export default App

