import { useState } from "react"


const FormDemo = () => {
    const[name,setName]=useState("")
const handleSubmit=(event)=>{
    event.preventDefault();//to avoid page refresh
    alert(`Form submitted with name: ${name}`);
    console.log(`Form submitted with name: ${event.target.name.value}`);
}
const handleChange=(event)=>{
  console.log(event.target.value);
    setName(event.target.value)
}
  return (
    <div>
        <h1>UserForm</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" value={name} onChange={handleChange}/>
        <p>Your name is: {name}</p>
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}
export default FormDemo;