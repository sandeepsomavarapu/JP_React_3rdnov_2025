import React, { useRef,useState } from 'react'

const UncontrolledFormDemo = () => {
    const username=useRef("");//ref for uncontrolled component
    const handleSubmit=(event)=>{
        event.preventDefault();//to avoid page refresh
        alert(`Form submitted with name: ${username.current.value}`);
        console.log(`Form submitted with name: ${event.target.name.value}`);
    }
  return (
    <div>
        <h1>UncontrolledUserForm</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Name:</label>
        <input type="text"  ref={username} />
        <p>Your name is2: {username.current?.value}</p>
        <button type="submit">Submit</button>
      </form>
    </div>
  )
}
export default UncontrolledFormDemo;