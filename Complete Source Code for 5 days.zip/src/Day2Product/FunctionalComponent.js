import React, { useState } from 'react'//rafc

const FunctionalComponent = () => {
        const [state,setState]=useState(false)

  return (
    <div>
      {
      state 
      ?
      (<button onClick={()=>setState(false)}>LOGIN</button>)
      :
      (<button onClick={()=>setState(true)}>LOGOUT</button>)
      }
    </div>
  )
}

export default FunctionalComponent
