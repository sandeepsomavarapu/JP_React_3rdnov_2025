
import React, { useState } from 'react';

const Products = () => {
    const [products, setProducts] = useState([
        { productId: 1, productName: "samsung", price: 45000 },
        { productId: 2, productName: "dell", price: 45600 },
        { productId: 3, productName: "lenovo", price: 42300 },
        { productId: 4, productName: "apple", price: 42200 },
    ]);
    const [operation,setOperation]=useState("ADD");
    const [product, setProduct] = useState({ productId: "", productName: "", price: "" });
    const handleDelete = (id) => {
        //setProducts(products.filter((product) => product.productId !== id));
          const  index=products.findIndex((product) => product.productId === id);
            products.splice(index, 1);
        setProducts([...products]);
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(product);
        if(operation==="UPDATE"){
            const index=products.findIndex(pro=>pro.productId===product.productId);
            products[index]=product;
            setProducts([...products]);
            setOperation("ADD");
            setProduct({productId:"",productName:"",price:""});
        }
        else{
        setProducts([...products, product]);
        setProduct({ productId: "", productName: "", price: "" });
        }
    }
    const handleEdit=(product)=>{
        setOperation("UPDATE");
        setProduct(product);
    }
    const handleChange=(e)=>{
        console.log(e.target.name,e.target.value);
        const{name,value}=e.target;//names:productId,productName,price values:... 
        setProduct({...product,[name]:value})
        setProducts([...products]);
    }
    return (
        <div>
            <div>
                <table className="table table-hover table-warning">
                    <thead>
                        <tr>
                            <th>Product Id</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map((product) => (
                            <tr key={product.productId}>
                                <td>{product.productId}</td>
                                <td>{product.productName}</td>
                                <td>{product.price}</td>
                                <td>
                                    <i className="fa-solid fa-trash" onClick={() => handleDelete(product.productId)}></i>&nbsp;
                                    <i className="fa-solid fa-pen" onClick={()=>handleEdit(product)}></i>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div>
                <h1>{operation} Product</h1>
                <form onSubmit={handleSubmit}>
                    <label>Product Id:</label>
                    <input
                        type="number" name="productId" disabled={operation === "UPDATE"} value={product.productId} onChange={handleChange} />
                    <br />
                    <label>Product Name:</label>
                    <input
                        type="text" name='productName' value={product.productName} onChange={handleChange} />
                    <br />
                    <label>Price:</label>
                    <input
                        type="number" name='price' value={product.price} onChange={handleChange} />
                    <br />
                    <button type="submit">{operation} Product</button>
                </form>
            </div>
        </div>
    );
};

export default Products;