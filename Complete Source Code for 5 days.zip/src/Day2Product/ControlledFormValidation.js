import React, { useState } from "react";

const ControlledFormValidation = () => {
  const [username, setUsername] = useState("");
  const [error, setError] = useState("username is required");

  const handleChange = (e) => {
    const value = e.target.value;
    setUsername(value);
    // Dynamic validation
    if (value.trim() === "") {
      setError("Username is required");
    } else if (value.length < 3) {
      setError("Username must be at least 3 characters");
    } else {
      setError(""); // Clear error if valid
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (username.trim() === "" || error) {
      alert("Please fix errors before submitting");
      return;
    }
    alert(`Form submitted! Username: ${username}`);
  };
  return (
    <form onSubmit={handleSubmit}>
      <label>UserName:</label>
      <input
        type="text"
        value={username}
        onChange={handleChange}
      />
      {error && <p style={{ color: "red" }}>{error}</p>}
      <button disabled={ error} type="submit">
        Submit
      </button>
    </form>
  );
};

export default ControlledFormValidation;