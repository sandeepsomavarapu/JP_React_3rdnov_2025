import React, { Component } from 'react'//rcc

export default class ClassComponent extends Component {

  constructor(props) {
    super(props)
    this.state = {
      name: 'Class Component'
    }
  }
  updateState=()=>{
    this.setState({name: 'Class Component Updated Twice'})
  }
  render() {
    return (
      <div>
        <h1>{this.state.name}</h1>
        <button onClick={()=>{this.setState({name: 'Class Component Updated'})}}>Click Me</button>
        <button onClick={this.updateState}>Click To Update Again</button>

      </div>
    )
  }
}
