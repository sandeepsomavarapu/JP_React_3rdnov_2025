import React, { useRef, useState } from "react";
const UncontrolledFormValidation = () => {
  const usernameRef = useRef(); // first change for uncontrolled input
  const [error, setError] = useState("");
  const handleChange = () => {
    const value = usernameRef.current.value;// get the current value from ref
    if (value.trim() === "") {
      setError("Username is required");
    } else if (value.length < 3) {
      setError("Username must be at least 3 characters");
    } else {
      setError("");
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const value = usernameRef.current.value;// get the current value from ref
    if (value.trim() === "" || error) {
      alert("Please fix errors before submitting");
      return;
    }
    alert(`Form submitted! Username: ${value}`);
    console.log("Form submitted!" );
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>UserName:</label>
      <input
        type="text"
        ref={usernameRef}// attach ref to input
        onChange={handleChange}
      />
      {error && <p style={{ color: "red" }}>{error}</p>}
      <button disabled={!usernameRef.current?.value || error} type="submit">
        Submit
      </button>
    </form>
  );
};

export default UncontrolledFormValidation;