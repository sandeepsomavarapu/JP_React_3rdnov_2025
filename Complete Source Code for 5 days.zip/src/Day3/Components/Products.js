import React from 'react'

const Products = () => {
  return (
    <div>
      <h1>Products Component</h1>
    </div>
  )
}

export default Products
