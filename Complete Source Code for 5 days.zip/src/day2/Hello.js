
function Hi(){
    return <h2>Am from Hi Component</h2>
}
export {Hi};

function Hello(){
    return <h2>Am from Hello Component</h2>
}
export default Hello;