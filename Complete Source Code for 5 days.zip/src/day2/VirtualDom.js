import { useState, useEffect } from "react";

export default function VirtualDom() {
  const [items] = useState(Array.from({ length: 10000 }, (_, i) => `Item ${i}`));

  useEffect(() => {
    console.time("Virtual DOM");
    // React will render the list here
    console.timeEnd("Virtual DOM");
  }, []);

  return (
    <ul>
      {items.map((item, index) => <li key={index}>{item}</li>)}
    </ul>
  );
}
