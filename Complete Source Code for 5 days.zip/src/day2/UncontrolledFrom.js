import React, { useRef } from "react";

const UncontrolledForm = () => {
  const usernameRef = useRef();
  const bioRef = useRef();
  const roleRef = useRef();
  const genderMaleRef = useRef();
  const genderFemaleRef = useRef();
  const genderOtherRef = useRef();
  const codingRef = useRef();
  const musicRef = useRef();
  const sportsRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Collect values from refs
    const username = usernameRef.current.value;
    const bio = bioRef.current.value;
    const role = roleRef.current.value;

    let gender = "";
    if (genderMaleRef.current.checked) gender = "male";
    if (genderFemaleRef.current.checked) gender = "female";
    if (genderOtherRef.current.checked) gender = "other";

    const interests = [];
    if (codingRef.current.checked) interests.push("coding");
    if (musicRef.current.checked) interests.push("music");
    if (sportsRef.current.checked) interests.push("sports");

    const formData = { username, bio, role, gender, interests };

    console.log("Form Submitted:", formData);
    alert(JSON.stringify(formData));//
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Uncontrolled Form Example</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Username:
          <input type="text" ref={usernameRef} />
        </label>
        <br /><br />
        <label>
          Bio:
          <textarea ref={bioRef} />
        </label>
        <br /><br />
        <label>
          Role:
          <select ref={roleRef} defaultValue="user">
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="moderator">Moderator</option>
          </select>
        </label>
        <br /><br />
        <label>Gender:</label>
        <input type="radio" name="gender" ref={genderMaleRef} /> Male
        <input type="radio" name="gender" ref={genderFemaleRef} /> Female
        <input type="radio" name="gender" ref={genderOtherRef} /> Other
        <br /><br />
        <label>Interests:</label>
        <input type="checkbox" ref={codingRef} /> Coding
        <input type="checkbox" ref={musicRef} /> Music
        <input type="checkbox" ref={sportsRef} /> Sports
        <br /><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default UncontrolledForm;
