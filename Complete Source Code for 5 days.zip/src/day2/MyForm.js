export default function MyForm() {
  const handleSubmit = (event) => {
    event.preventDefault();
    alert("Form submitted!");
    // Page will reload after this alert
  };

  return (
    <form onSubmit={handleSubmit}>
      <button type="submit">Submit</button>
    </form>
  );
}