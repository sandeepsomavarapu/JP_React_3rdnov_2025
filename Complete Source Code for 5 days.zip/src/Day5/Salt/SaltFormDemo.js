
import { Button } from "@salt-ds/core";
import { Input } from "@salt-ds/core";
import e from "express";
import React from 'react'
import { useState } from 'react'


const SaltFormDemo = () => {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
      });

  return (
    <div>
      <form>
        <Input bordered={true} defaultValue="Username" style={{ width: "256px" }} onChange={(e)=>setFormData({...formData,username:e.target.value})} />
       <Input bordered={true} inputProps={{type:"password"}} defaultValue="Username" style={{ width: "256px" }} onChange={(e) => setFormData({ ...formData, password: e.target.value })}/>
    
      </form>
    </div>
  )
}

export default SaltFormDemo
