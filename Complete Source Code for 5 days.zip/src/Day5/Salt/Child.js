import React from 'react'

const Child = (props) => {
  return (
    <div align="center">
      <h1>From Child Component</h1>
      <h2>Username:{props.username}</h2>
    </div>
  )
}

export default Child
