import React from 'react'
import Child from './Child'

const Parent = (props) => {
  return (
    <div>
      {/* <h1>Parent Component {props.username}</h1> */}
      <Child username={props.username} />
    </div>
  )
}

export default Parent
