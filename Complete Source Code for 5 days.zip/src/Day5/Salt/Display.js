
function Display({ text }) {
  return <p>You typed: {text}</p>;
}

export default Display;

