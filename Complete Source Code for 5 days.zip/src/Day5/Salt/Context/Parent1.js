import P1Child1 from './P1Child1'
const Parent1 = () => {
  return (
    <div>
      <h1>Parent1</h1>
      <P1Child1></P1Child1>
    </div>
  )
}

export default Parent1
