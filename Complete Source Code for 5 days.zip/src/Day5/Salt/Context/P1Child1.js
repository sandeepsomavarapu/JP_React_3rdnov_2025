import React, { useContext } from 'react'
import { Context } from './Context';

const P1Child1 = () => {
   const commonData =useContext(Context);
  return (
    <div>
      <h1>Parent1 Child 1 {commonData.id}{commonData.name}</h1>
    </div>
  )
}

export default P1Child1
