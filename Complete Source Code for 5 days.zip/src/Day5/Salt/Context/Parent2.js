import React from 'react'

const Parent2 = () => {
  return (
    <div>
      <h1>Parent2</h1>
    </div>
  )
}

export default Parent2
