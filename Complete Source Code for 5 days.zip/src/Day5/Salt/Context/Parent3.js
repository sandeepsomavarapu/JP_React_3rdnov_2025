import React from 'react'

const Parent3 = () => {
  return (
    <div>
      <h1>Parent3</h1>
    </div>
  )
}

export default Parent3
